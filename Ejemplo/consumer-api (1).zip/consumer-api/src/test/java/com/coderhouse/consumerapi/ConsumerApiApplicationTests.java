package com.coderhouse.consumerapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
